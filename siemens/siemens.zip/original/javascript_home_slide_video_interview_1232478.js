
if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,14);
  if (part == "sdc_article_1")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1237131l0mno1237139st55u20z","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l1mno1237139st55u20z","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l2mno1237139st55u20z","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l3mno1237139st55u20z","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l4mno1237139st55u20z","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l5mno1237139st55u20z","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l6mno1237139st55u20z","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l17mno1237139st55u20z","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l91mno1237139st55u20z","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_article_2")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l0mno1237140st55u20z","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l1mno1237140st55u20z","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l2mno1237140st55u20z","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l3mno1237140st55u20z","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l4mno1237140st55u20z","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l5mno1237140st55u20z","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l6mno1237140st55u20z","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l17mno1237140st55u20z","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l91mno1237140st55u20z","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_article_3")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l0mno1237144st55u20z","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l1mno1237144st55u20z","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l2mno1237144st55u20z","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l3mno1237144st55u20z","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l4mno1237144st55u20z","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l5mno1237144st55u20z","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l6mno1237144st55u20z","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l17mno1237144st55u20z","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1227878l91mno1237144st55u20z","","width=788,height=570"); break;
    }
  }

//Slideshow

  if (part == "sdc_slishow_1")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1222504stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1222504stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1222504stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1222504stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1222504stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1222504stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1222504stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1222504stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1222504stu20z&","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_slishow_2")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1237495stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1237495stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1237495stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1237495stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1237495stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1237495stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1237495stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1237495stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1237495stu20z&","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_slishow_3")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1224007stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1224007stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1224007stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1224007stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1224007stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1224007stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1224007stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1224007stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1224007stu20z&","","width=788,height=570"); break;
    }
  }

//Video

  if (part == "sdc_avimpeg_1")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1239155stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1239155stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1239155stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1239155stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1239155stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1239155stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1239155stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1239155stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1239155stu20z&","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_avimpeg_2")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1239246stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1239246stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1239246stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1239246stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1239246stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1239246stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1239246stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1239246stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1239246stu20z&","","width=788,height=570"); break;
    }
  }  if (part == "sdc_avimpeg_3")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1239247stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1239247stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1239247stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1239247stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1239247stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1239247stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1239247stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1239247stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1239247stu20z&","","width=788,height=570"); break;
    }
  }

//Interview

  if (part == "sdc_intview_1")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1224109stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1224109stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1224109stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1224109stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1224109stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1224109stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1224109stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1224109stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1224109stu20z&","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_intview_2")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1224109stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1224109stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1224109stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1224109stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1224109stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1224109stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1224109stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1224109stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1224109stu20z&","","width=788,height=570"); break;
    }
  }
  if (part == "sdc_intview_3")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
     case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l0mno1237583stu20z&","","width=788,height=570"); break;
     case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l1mno1237583stu20z&","","width=788,height=570"); break;
     case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l2mno1237583stu20z&","","width=788,height=570"); break;
     case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l3mno1237583stu20z&","","width=788,height=570"); break;
     case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l4mno1237583stu20z&","","width=788,height=570"); break;
     case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l5mno1237583stu20z&","","width=788,height=570"); break;
     case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l6mno1237583stu20z&","","width=788,height=570"); break;
     case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l17mno1237583stu20z&","","width=788,height=570"); break;
     case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=pJ502cfi1218666l91mno1237583stu20z&","","width=788,height=570"); break;
    }
  }
}

//External language

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,14);
  if (part == "sdc_jlangidex")
  {
  var langid = mystring.substring(15,16);
  switch(langid)
    {
      case "0": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl0mi1237131&sdc_entdoc=true&"; break;
      case "1": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl1mi1237131&sdc_entdoc=true&"; break;
      case "2": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl2mi1237131&sdc_entdoc=true&"; break;
      case "3": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl3mi1237131&sdc_entdoc=true&"; break;      
      case "4": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl4mi1237131&sdc_entdoc=true&"; break;      
      case "5": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl5mi1237131&sdc_entdoc=true&"; break;      
      case "6": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl6mi1237131&sdc_entdoc=true&"; break;
      case "7": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl17mi1237131&sdc_entdoc=true&"; break;
      case "8": location.href="http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl91mi1237131&sdc_entdoc=true&"; break;
    }
  }  
}

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,12);
  if (part == "scd_jlangid")
  {
  var langid = mystring.substring(13,14);
  switch(langid)
    {
      case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl0mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl1mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl2mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl3mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl4mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl5mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl6mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl17mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl91mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
    }
  }  
}

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,12);
  if (part == "sdc_jlangid")
  {
  var langid = mystring.substring(13,14);
  switch(langid)
    {
      case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl0mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl1mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl2mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl3mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl4mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl5mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl6mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl17mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
      case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czsu20o1237131pJ502nfl91mi1237131&sdc_entdoc=true&","","width=788,height=570"); break;
    }
  }  
}

//Leserbrief

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,12);
  if (part == "sdc_jletter")
  {
  var langid = mystring.substring(13,14);
  switch(langid)
    {
      case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl0mi1187993","","width=788,height=570"); break;
      case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl1mi1187993","","width=788,height=570"); break;
      case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl2mi1187993","","width=788,height=570"); break;
      case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl3mi1187993","","width=788,height=570"); break;
      case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl4mi1187993","","width=788,height=570"); break;
      case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl5mi1187993","","width=788,height=570"); break;
      case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl6mi1187993","","width=788,height=570"); break;
      case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl17mi1187993","","width=788,height=570"); break;
      case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=t4czs3u20o1182828pJ502nfl91mi1187993","","width=788,height=570"); break;
    }
  }  
}

//Datenschutz

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,12);
  if (part == "sdc_jpolicy")
  {
  var langid = mystring.substring(13,14);
  switch(langid)
    {
      case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl0mi1162375","","width=788,height=570"); break;
      case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl1mi1162375","","width=788,height=570"); break;
      case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl2mi1162375","","width=788,height=570"); break;
      case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl3mi1162375","","width=788,height=570"); break;
      case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl4mi1162375","","width=788,height=570"); break;
      case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl5mi1162375","","width=788,height=570"); break;
      case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl6mi1162375","","width=788,height=570"); break;
      case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl17mi1162375","","width=788,height=570"); break;
      case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs7u20o1223277pJ502nfl91mi1162375","","width=788,height=570"); break;
    }
  }  
}

//Newsletter Configuration

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,12);
  if (part == "sdc_jconfid")
  {
  var langid = mystring.substring(13,14);
  switch(langid)
    {
      case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl0mi1223343","","width=788,height=570"); break;
      case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl1mi1223343","","width=788,height=570"); break;
      case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl2mi1223343","","width=788,height=570"); break;
      case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl3mi1223343","","width=788,height=570"); break;
      case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl4mi1223343","","width=788,height=570"); break;
      case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl5mi1223343","","width=788,height=570"); break;
      case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl6mi1223343","","width=788,height=570"); break;
      case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl17mi1223343","","width=788,height=570"); break;
      case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223196pJ502nfl91mi1223343","","width=788,height=570"); break;
    }
  }  
}

//Newsletter Unsubscribe

if(window.location.search != "")
{
var mystring =  window.location.search;
var part = mystring.substring(1,12);
  if (part == "sdc_junsubs")
  {
  var langid = mystring.substring(13,14);
  switch(langid)
    {
      case "0": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl0mi1223343","","width=788,height=570"); break;
      case "1": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl1mi1223343","","width=788,height=570"); break;
      case "2": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl2mi1223343","","width=788,height=570"); break;
      case "3": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl3mi1223343","","width=788,height=570"); break;
      case "4": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl4mi1223343","","width=788,height=570"); break;
      case "5": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl5mi1223343","","width=788,height=570"); break;
      case "6": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl6mi1223343","","width=788,height=570"); break;
      case "7": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl17mi1223343","","width=788,height=570"); break;
      case "8": window.open("http://www.siemens.com/index.jsp?sdc_p=t55czs6u20o1223350pJ502nfl91mi1223343","","width=788,height=570"); break;
    }
  }  
}