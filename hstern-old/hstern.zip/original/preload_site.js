// Preload de imagens gerais usadas em todo o site
function preloadImages(){

	//pI('/img/ani_st_off.gif')
	//pI('/img/ani_st_on.gif')

	pI('/img/mn_institucional_off_PT.gif')
	pI('/img/mn_institucional_on_PT.gif')
	
		pI('/img/mn_historia_off_PT.gif')
		pI('/img/mn_historia_on_PT.gif')
		
			pI('/img/mn_deaaz_off_PT.gif')
			pI('/img/mn_deaaz_on_PT.gif')
	
			pI('/img/mn_estreladesucesso_off_PT.gif')
			pI('/img/mn_estreladesucesso_on_PT.gif')
		
		pI('/img/mn_tourvirtual_off_PT.gif')
		pI('/img/mn_tourvirtual_on_PT.gif')
		
			pI('/img/mn_tourvirtual_prodjoias_off_PT.gif')
			pI('/img/mn_tourvirtual_prodjoias_on_PT.gif')

			pI('/img/mn_tourvirtual_prodrelogios_off_PT.gif')
			pI('/img/mn_tourvirtual_prodrelogios_on_PT.gif')
		
		pI('/img/mn_carreira_off_PT.gif')
		pI('/img/mn_carreira_on_PT.gif')
		
			pI('/img/mn_como_trab_off_PT.gif')
			pI('/img/mn_oportunidades_off_PT.gif')
			pI('/img/mn_trainees_off_PT.gif')
			pI('/img/mn_curriculo_off_PT.gif')
			
			pI('/img/mn_como_trab_on_PT.gif')
			pI('/img/mn_oportunidades_on_PT.gif')
			pI('/img/mn_trainees_on_PT.gif')
			pI('/img/mn_curriculo_on_PT.gif')
		
		pI('/img/mn_visao_off_PT.gif')
		pI('/img/mn_visao_on_PT.gif')
		
		pI('/img/mn_evolucao_off_PT.gif')
		pI('/img/mn_evolucao_on_PT.gif')
	
	pI('/img/mn_loja_virtual_off_PT.gif')
	pI('/img/mn_loja_virtual_on_PT.gif')
	
		pI('/img/mn_joias_off_PT.gif')
		pI('/img/mn_joias_on_PT.gif')
	
		pI('/img/mn_relogios_off_PT.gif')
		pI('/img/mn_relogios_on_PT.gif')
		
		pI('/img/mn_boutique_off_PT.gif')
		pI('/img/mn_boutique_on_PT.gif')
	
		pI('/img/mn_lancamento_off_PT.gif')
		pI('/img/mn_lancamento_on_PT.gif')
	
		pI('/img/mn_anuncio_off_PT.gif')
		pI('/img/mn_anuncio_on_PT.gif')

	pI('/img/mn_revista_off_PT.gif')
	pI('/img/mn_revista_on_PT.gif')
	
	pI('/img/mn_atendimento_off_PT.gif')
	pI('/img/mn_atendimento_on_PT.gif')
	
		pI('/img/mn_busca_de_os_off_PT.gif')
		pI('/img/mn_busca_de_os_on_PT.gif')
		
		pI('/img/mn_dicas_e_curiosidades_off_PT.gif')
		pI('/img/mn_dicas_e_curiosidades_on_PT.gif')
		
		pI('/img/mn_lojas_agentes_off_PT.gif')
		pI('/img/mn_lojas_agentes_on_PT.gif')
		
		pI('/img/mn_fale_conosco_off_PT.gif')
		pI('/img/mn_fale_conosco_on_PT.gif')
		
		pI('/img/mn_faq_off_PT.gif')
		pI('/img/mn_faq_on_PT.gif')
	
}
